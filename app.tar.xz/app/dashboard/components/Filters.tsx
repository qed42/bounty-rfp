"use client"

import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

export function Filters() {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm space-y-4">
      {/* ---- Row 1 ---- */}
      <div className="flex flex-wrap justify-between gap-4">
        {/* 1. Service Keywords */}
        <div className="flex flex-col space-y-3">
          <Label>Service Keywords</Label>
          <Select>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select keyword" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="drupal">Drupal</SelectItem>
              <SelectItem value="cms">CMS</SelectItem>
              <SelectItem value="website-design">Website design</SelectItem>
              <SelectItem value="react-native">React Native</SelectItem>
              <SelectItem value="genai">GenAI</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 2. Budget */}
        <div className="flex flex-col space-y-3">
          <Label>Budget (Min)</Label>
          <Input type="number" defaultValue={40000} className="w-[150px]" />
        </div>

        {/* 3. Sector */}
        <div className="flex flex-col space-y-3">
          <Label>Sectors</Label>
          <Select>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select sector" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="govt">Government</SelectItem>
              <SelectItem value="tech">Technology</SelectItem>
              <SelectItem value="ecom">E-Commerce</SelectItem>
              <SelectItem value="edu">Education</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 4. Geographic Eligibility */}
        <div className="flex flex-col space-y-3">
          <Label>Geographic Eligibility</Label>
          <Select>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select country" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="us">US</SelectItem>
              <SelectItem value="uk">UK</SelectItem>
              <SelectItem value="india">India</SelectItem>
              <SelectItem value="uae">UAE</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 5. RFP Type */}
        <div className="flex flex-col space-y-3">
          <Label>RFP Type</Label>
          <Select>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="rfp">RFP</SelectItem>
              <SelectItem value="rfq">RFQ</SelectItem>
              <SelectItem value="rfi">RFI</SelectItem>
              <SelectItem value="eoi">EOI</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 6. Deadline */}
        <div className="flex flex-col space-y-3">
          <Label>Deadline (Days)</Label>
          <Input type="number" defaultValue={4} className="w-[100px]" />
        </div>
      </div>

      {/* ---- Row 2 ---- */}
      <div className="flex flex-wrap justify-between gap-4">
        {/* 7. Preferred Tech Stack */}
        <div className="flex flex-col space-y-3">
          <Label>Preferred Tech Stack</Label>
          <Select>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select tech" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="drupal">Drupal</SelectItem>
              <SelectItem value="nodejs">NodeJS</SelectItem>
              <SelectItem value="reactjs">ReactJS</SelectItem>
              <SelectItem value="vuejs">VueJS</SelectItem>
              <SelectItem value="genai">GenAI</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 8. Certifications */}
        <div className="flex flex-col space-y-3">
          <Label>Certifications</Label>
          <Select>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select cert" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="iso">ISO</SelectItem>
              <SelectItem value="istqb">ISTQB</SelectItem>
              <SelectItem value="acquia">Acquia Partner</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 9. Language */}
        <div className="flex flex-col space-y-3">
          <Label>Language</Label>
          <Select>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="English" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="english">English</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 10. Onsite Requirement */}
        <div className="flex flex-col space-y-3 items-start">
          <Label>Exclude Onsite</Label>
          <Switch />
        </div>

        {/* 11. Portal Priority */}
        <div className="flex flex-col space-y-3">
          <Label>Portal Priority</Label>
          <Select>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="conversion">By Conversion Rate</SelectItem>
              <SelectItem value="reliability">By Reliability</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  )
}
