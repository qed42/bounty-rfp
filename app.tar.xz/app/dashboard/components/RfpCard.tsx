import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export function RfpCard({ rfp }: { rfp: any }) {
  const cleanTitle = rfp.title.split("\n")[0]; // take first line only
  const relevance =
    rfp.score !== null && rfp.score !== undefined
      ? Math.round(rfp.score * 100)
      : null;

  return (
    <a
      href={rfp.url}
      target="_blank"
      rel="noopener noreferrer"
      className="block h-full"
      aria-label={`Open RFP: ${cleanTitle}`}
    >
      <Card className="hover:shadow-md transition-all cursor-pointer h-full">
        <CardHeader>
          <CardTitle className="text-lg font-semibold line-clamp-2">
            {cleanTitle}
          </CardTitle>

          <p className="text-xs text-muted-foreground">
            Source: {rfp.portal_name}
          </p>
        </CardHeader>

        <CardContent>
          <p className="text-sm text-gray-600 line-clamp-2">
            {rfp.description ?? "No description provided"}
          </p>

          {relevance !== null && (
            <p className="text-xs text-blue-600 mt-2">
              Relevance: {relevance}%
            </p>
          )}

          {rfp.enriched === false && (
            <p className="text-xs text-orange-500 mt-1">
              Not enriched
            </p>
          )}
        </CardContent>
      </Card>
    </a>
  );
}
