"use client";

import { useEffect, useState } from "react";
import { Filters } from "./components/Filters";
import { RfpCard } from "./components/RfpCard";
import type { Rfp } from "./types";

export default function DashboardPage() {
  const [rfps, setRfps] = useState<Rfp[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRfps = async () => {
      try {
        const res = await fetch(
          "http://65.2.128.237:8000/api/v1/rfps/?limit=50"
        );
        const data: Rfp[] = await res.json();

        // ✅ Filter out junk / navigation rows
        const cleaned = data.filter(
          (rfp) =>
            rfp.url &&
            !["Next", "Home", "Artificial Intelligence"].includes(
              rfp.title.trim()
            )
        );

        setRfps(cleaned);
      } catch (err) {
        console.error("Failed to fetch RFPs", err);
      } finally {
        setLoading(false);
      }
    };

    fetchRfps();
  }, []);

  if (loading) {
    return <p className="text-muted-foreground">Loading RFPs…</p>;
  }

  return (
    <div className="space-y-6">
      <Filters />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {rfps.map((rfp) => (
          <RfpCard key={rfp._id} rfp={rfp} />
        ))}
      </div>
    </div>
  );
}
