import "./globals.css"
import { ReactQueryClientProvider } from "@/lib/react-query"
import { Sidebar } from "@/components/Sidebar"
import { Navbar } from "@/components/Navbar"

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <div className="flex flex-col flex-1">
          <Navbar />
          <ReactQueryClientProvider>
            <main className="p-6">{children}</main>
          </ReactQueryClientProvider>
        </div>
      </body>
    </html>
  )
}
