export function Navbar() {
  return (
    <header className="h-14 bg-white border-b flex items-center justify-between px-6">
      <span className="font-semibold">Welcome, Presales</span>
    </header>
  )
}
