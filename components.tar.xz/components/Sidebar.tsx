export function Sidebar() {
  return (
    <aside className="w-64 bg-white shadow-lg p-4">
      <h1 className="font-bold text-xl mb-6">RFP Dashboard</h1>
      <nav className="space-y-2">
        <a href="/dashboard" className="block hover:bg-gray-100 rounded p-2">Dashboard</a>
        <a href="/reports" className="block hover:bg-gray-100 rounded p-2">Reports</a>
        <a href="/settings" className="block hover:bg-gray-100 rounded p-2">Settings</a>
      </nav>
    </aside>
  )
}
